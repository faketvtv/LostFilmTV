# LostFilm TV v0.8

Android TV / Google TV native launcher with LostFilm site browsing, search entry, local history/favorites storage, visible popup-window handling and external playback for direct compatible video URLs.

## Build with GitHub Actions
Upload the **contents** of this project to the repository root, including `.github/workflows/android.yml`, then open Actions and run `Build LostFilm TV APK`.

This is a client shell, not an independent licensed content catalog. The catalog and descriptions are served by LostFilm website. Search routing may need adjustment if the website changes its search URL. Torrent links are not converted to streams. Direct video playback works only when a provider exposes a normal compatible URL and the device has a suitable player installed.

## Install
Download the `LostFilmTV-APK` artifact from a successful Actions run, extract `app-debug.apk`, and install it on Android TV / Google TV.
