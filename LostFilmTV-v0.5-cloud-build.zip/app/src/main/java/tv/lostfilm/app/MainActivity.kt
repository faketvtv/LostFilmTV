package tv.lostfilm.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val site = "https://lostfilm.tv/"
    private lateinit var root: LinearLayout
    private lateinit var webContainer: FrameLayout
    private var mainWebView: WebView? = null
    private var popupWebView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(36, 28, 36, 28)
        setBackgroundColor(Color.rgb(16, 20, 28))
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 19f
        isFocusable = true
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 64).apply {
            bottomMargin = 14
        }
    }

    private fun showHome() {
        root = base()
        root.addView(TextView(this).apply {
            text = "LOSTFILM TV"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 26)
        })
        root.addView(button("Открыть LostFilm", ::openSite))
        root.addView(button("Избранное", { openSite() }))
        root.addView(button("История", { openSite() }))
        root.addView(TextView(this).apply {
            text = "Авторизуйтесь на сайте для доступа к просмотру. Ссылки, открываемые в новых окнах, поддерживаются. Совместимые прямые видеоссылки передаются внешнему плееру."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(4, 18, 4, 0)
        })
        setContentView(root)
        root.getChildAt(1).requestFocus()
    }

    private fun openSite() {
        webContainer = FrameLayout(this)
        val web = WebView(this)
        mainWebView = web
        configureWebView(web, isPopup = false)
        webContainer.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(webContainer)
        web.loadUrl(site)
    }

    private fun configureWebView(web: WebView, isPopup: Boolean) {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        web.settings.setSupportMultipleWindows(true)
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return handleUrl(request.url.toString())
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = handleUrl(url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                if (resultMsg == null) return false
                val popup = WebView(this@MainActivity)
                popupWebView?.let { closePopup(it) }
                popupWebView = popup
                configureWebView(popup, isPopup = true)
                webContainer.addView(popup, FrameLayout.LayoutParams(-1, -1))
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = popup
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView?) {
                popupWebView?.let { closePopup(it) }
            }
        }
    }

    private fun closePopup(popup: WebView) {
        if (popup.parent != null) webContainer.removeView(popup)
        popup.stopLoading()
        popup.destroy()
        if (popupWebView === popup) popupWebView = null
    }

    private fun handleUrl(url: String): Boolean {
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") return false

        val path = uri.path?.lowercase().orEmpty()
        val isVideo = listOf(".mp4", ".m3u8", ".mpd", ".mkv", ".webm").any { path.endsWith(it) }
        if (isVideo) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "Не найден внешний видеоплеер", Toast.LENGTH_LONG).show()
            }
            return true
        }
        // tracktor.site and its redirects are intentionally opened in WebView;
        // the site may need cookies, scripts, or an intermediate download page.
        return false
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val popup = popupWebView
        if (popup != null) {
            if (popup.canGoBack()) popup.goBack() else closePopup(popup)
            return
        }
        val web = mainWebView
        if (web != null && web.canGoBack()) {
            web.goBack()
        } else if (web != null) {
            web.stopLoading()
            web.destroy()
            mainWebView = null
            setContentView(root)
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        popupWebView?.let { closePopup(it) }
        mainWebView?.destroy()
        mainWebView = null
        super.onDestroy()
    }
}
