plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "tv.lostfilm.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "tv.lostfilm.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "0.4"
    }
}
