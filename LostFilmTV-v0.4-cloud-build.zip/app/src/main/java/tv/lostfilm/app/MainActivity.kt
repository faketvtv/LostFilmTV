package tv.lostfilm.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val site = "https://lostfilm.tv/"
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(36, 28, 36, 28)
        setBackgroundColor(Color.rgb(16, 20, 28))
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 19f
        isFocusable = true
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 64).apply {
            bottomMargin = 14
        }
    }

    private fun showHome() {
        root = base()
        root.addView(TextView(this).apply {
            text = "LOSTFILM TV"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 26)
        })
        root.addView(button("Открыть LostFilm", ::openSite))
        root.addView(button("Избранное", { openSite() }))
        root.addView(button("История", { openSite() }))
        root.addView(TextView(this).apply {
            text = "Для просмотра требуется доступ к сайту LostFilm. Воспроизведение открывается во внешнем приложении, если сайт предоставляет обычную прямую ссылку на видео."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(4, 18, 4, 0)
        })
        setContentView(root)
        root.getChildAt(1).requestFocus()
    }

    private fun openSite() {
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                handleUrl(request.url.toString())
            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = handleUrl(url)
        }
        web.loadUrl(site)
        setContentView(web)
    }

    private fun handleUrl(url: String): Boolean {
        val lower = url.lowercase()
        val video = listOf(".mp4", ".m3u8", ".mpd", ".mkv", ".webm").any { lower.contains(it) }
        if (video && (url.startsWith("https://") || url.startsWith("http://"))) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            return true
        }
        return false
    }
}
