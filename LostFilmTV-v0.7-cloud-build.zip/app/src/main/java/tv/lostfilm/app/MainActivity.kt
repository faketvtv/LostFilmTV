package tv.lostfilm.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val homeUrl = "https://lostfilm.tv/"
    private lateinit var root: LinearLayout
    private var web: WebView? = null
    private val prefs by lazy { getSharedPreferences("lostfilm_tv", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(34, 26, 34, 26)
        setBackgroundColor(Color.rgb(16, 20, 29))
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply {
            text = label
            textSize = 18f
            isFocusable = true
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 62).apply {
                bottomMargin = 12
            }
        })
    }

    private fun showHome() {
        root = base()
        root.addView(TextView(this).apply {
            text = "LOSTFILM TV"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        })
        addButton(root, "Каталог сериалов", { openSite(homeUrl) })
        addButton(root, "Поиск на LostFilm", { showSearch() })
        addButton(root, "Избранное", { openSaved("favorites") })
        addButton(root, "История просмотров", { openSaved("history") })
        addButton(root, "Открыть сайт LostFilm", { openSite(homeUrl) })
        root.addView(TextView(this).apply {
            text = "Каталог и карточки сериалов загружаются с сайта LostFilm. Прямые совместимые видеоссылки можно открыть во внешнем плеере."
            textSize = 14f
            setTextColor(Color.LTGRAY)
        })
        setContentView(root)
        root.getChildAt(1).requestFocus()
    }

    private fun showSearch() {
        root = base()
        root.addView(TextView(this).apply {
            text = "Поиск сериалов"
            textSize = 24f
            setTextColor(Color.WHITE)
        })
        val field = EditText(this).apply {
            hint = "Название сериала"
            textSize = 18f
            setSingleLine(true)
        }
        root.addView(field)
        addButton(root, "Искать на сайте", {
            val q = Uri.encode(field.text.toString().trim())
            if (q.isNotEmpty()) openSite("$homeUrl?search=$q")
            else Toast.makeText(this, "Введите название", Toast.LENGTH_SHORT).show()
        })
        addButton(root, "Назад", ::showHome)
        setContentView(root)
        field.requestFocus()
    }

    private fun openSaved(kind: String) {
        val values = prefs.getStringSet(kind, emptySet()).orEmpty().toList()
        root = base()
        root.addView(TextView(this).apply {
            text = if (kind == "favorites") "Избранное" else "История"
            textSize = 24f
            setTextColor(Color.WHITE)
        })
        if (values.isEmpty()) root.addView(TextView(this).apply {
            text = "Пока пусто. Добавляйте страницы сайта в избранное через меню приложения."
            setTextColor(Color.LTGRAY)
        })
        values.forEach { url -> addButton(root, url, { openSite(url) }) }
        addButton(root, "Назад", ::showHome)
        setContentView(root)
    }

    private fun saveUrl(kind: String, url: String) {
        val set = prefs.getStringSet(kind, emptySet()).orEmpty().toMutableSet()
        set.remove(url)
        set.add(url)
        while (set.size > 50) set.remove(set.first())
        prefs.edit().putStringSet(kind, set).apply()
    }

    private fun openSite(url: String) {
        val view = WebView(this)
        web = view
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.javaScriptCanOpenWindowsAutomatically = true
        // LostFilm opens episode/player pages through window.open on some pages.
        // Keep navigation in this WebView so the popup is not created invisibly.
        view.settings.setSupportMultipleWindows(true)
        view.settings.mediaPlaybackRequiresUserGesture = false
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, true)
        view.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                // Some LostFilm source links use target="_blank" / window.open.
                // Capture the popup and forward its destination to the visible WebView.
                val popup = WebView(this@MainActivity).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.javaScriptCanOpenWindowsAutomatically = true
                    settings.setSupportMultipleWindows(true)
                    settings.mediaPlaybackRequiresUserGesture = false
                    webChromeClient = object : WebChromeClient() {}
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                            val target = request.url.toString()
                            if (routeUrl(target)) return true
                            web?.loadUrl(target)
                            return true
                        }
                        @Deprecated("Deprecated in Java")
                        override fun shouldOverrideUrlLoading(v: WebView, target: String): Boolean {
                            if (routeUrl(target)) return true
                            web?.loadUrl(target)
                            return true
                        }
                    }
                }
                transport.webView = popup
                resultMsg.sendToTarget()
                return true
            }
        }
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean =
                routeUrl(request.url.toString())
            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(v: WebView, target: String): Boolean = routeUrl(target)
            override fun onPageFinished(v: WebView, pageUrl: String) {
                saveUrl("history", pageUrl)
            }
        }
        setContentView(view)
        view.loadUrl(url)
    }

    private fun routeUrl(url: String): Boolean {
        val uri = try { Uri.parse(url) } catch (_: Exception) { return true }
        val scheme = uri.scheme?.lowercase() ?: return true

        if (scheme != "http" && scheme != "https") {
            return try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
                true
            } catch (_: Exception) {
                Toast.makeText(this, "Нет приложения для открытия этой ссылки", Toast.LENGTH_LONG).show()
                true
            }
        }

        val path = uri.path.orEmpty().lowercase()
        val fullUrl = url.lowercase()
        val videoExtensions = listOf(".mp4", ".m3u8", ".mpd", ".webm", ".mkv", ".mov")
        val isVideo = videoExtensions.any { path.endsWith(it) } ||
            (uri.host.orEmpty().contains("tracktor.site", true) &&
                (path.contains("play") || path.contains("video") || path.contains("stream")))

        if (isVideo) {
            return try {
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "video/*")
                    addCategory(Intent.CATEGORY_DEFAULT)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
                true
            } catch (_: Exception) {
                Toast.makeText(this, "Не найден внешний видеоплеер. Установите VLC или другой плеер.", Toast.LENGTH_LONG).show()
                true
            }
        }

        // Torrent downloads are not playable as direct video streams.
        if (path.endsWith(".torrent") || fullUrl.contains("magnet:")) {
            Toast.makeText(this, "Это торрент-ссылка, а не прямая видеоссылка", Toast.LENGTH_LONG).show()
            return true
        }

        return false
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val current = web
        if (current != null && current.canGoBack()) current.goBack()
        else { web = null; showHome() }
    }
}
