package tv.lostfilm.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val homeUrl = "https://lostfilm.tv/"
    private lateinit var root: LinearLayout
    private var web: WebView? = null
    private val prefs by lazy { getSharedPreferences("lostfilm_tv", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(34, 26, 34, 26)
        setBackgroundColor(Color.rgb(16, 20, 29))
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply {
            text = label
            textSize = 18f
            isFocusable = true
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 62).apply {
                bottomMargin = 12
            }
        })
    }

    private fun showHome() {
        root = base()
        root.addView(TextView(this).apply {
            text = "LOSTFILM TV"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        })
        addButton(root, "Каталог сериалов", { openSite(homeUrl) })
        addButton(root, "Поиск на LostFilm", { showSearch() })
        addButton(root, "Избранное", { openSaved("favorites") })
        addButton(root, "История просмотров", { openSaved("history") })
        addButton(root, "Открыть сайт LostFilm", { openSite(homeUrl) })
        root.addView(TextView(this).apply {
            text = "Каталог и карточки сериалов загружаются с сайта LostFilm. Прямые совместимые видеоссылки можно открыть во внешнем плеере."
            textSize = 14f
            setTextColor(Color.LTGRAY)
        })
        setContentView(root)
        root.getChildAt(1).requestFocus()
    }

    private fun showSearch() {
        root = base()
        root.addView(TextView(this).apply {
            text = "Поиск сериалов"
            textSize = 24f
            setTextColor(Color.WHITE)
        })
        val field = EditText(this).apply {
            hint = "Название сериала"
            textSize = 18f
            setSingleLine(true)
        }
        root.addView(field)
        addButton(root, "Искать на сайте", {
            val q = Uri.encode(field.text.toString().trim())
            if (q.isNotEmpty()) openSite("$homeUrl?search=$q")
            else Toast.makeText(this, "Введите название", Toast.LENGTH_SHORT).show()
        })
        addButton(root, "Назад", ::showHome)
        setContentView(root)
        field.requestFocus()
    }

    private fun openSaved(kind: String) {
        val values = prefs.getStringSet(kind, emptySet()).orEmpty().toList()
        root = base()
        root.addView(TextView(this).apply {
            text = if (kind == "favorites") "Избранное" else "История"
            textSize = 24f
            setTextColor(Color.WHITE)
        })
        if (values.isEmpty()) root.addView(TextView(this).apply {
            text = "Пока пусто. Добавляйте страницы сайта в избранное через меню приложения."
            setTextColor(Color.LTGRAY)
        })
        values.forEach { url -> addButton(root, url, { openSite(url) }) }
        addButton(root, "Назад", ::showHome)
        setContentView(root)
    }

    private fun saveUrl(kind: String, url: String) {
        val set = prefs.getStringSet(kind, emptySet()).orEmpty().toMutableSet()
        set.remove(url)
        set.add(url)
        while (set.size > 50) set.remove(set.first())
        prefs.edit().putStringSet(kind, set).apply()
    }

    private lateinit var webContainer: android.widget.FrameLayout
    private val popupStack = mutableListOf<WebView>()

    private fun openSite(url: String) {
        popupStack.clear()
        webContainer = android.widget.FrameLayout(this)
        val mainView = createWebView()
        web = mainView
        webContainer.addView(mainView, android.widget.FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(webContainer)
        mainView.loadUrl(url)
    }

    private fun createWebView(): WebView {
        val view = WebView(this)
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.javaScriptCanOpenWindowsAutomatically = true
        view.settings.setSupportMultipleWindows(true)
        view.settings.mediaPlaybackRequiresUserGesture = true
        view.settings.useWideViewPort = false
        view.settings.loadWithOverviewMode = false
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, true)

        view.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                val popup = createWebView()
                popupStack.add(popup)
                webContainer.addView(popup, android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                ))
                popup.bringToFront()
                transport.webView = popup
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView?) {
                val popup = window ?: return
                popupStack.remove(popup)
                webContainer.removeView(popup)
                popup.destroy()
                if (popupStack.isEmpty()) web?.bringToFront()
                else popupStack.last().bringToFront()
            }
        }

        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean =
                routeUrl(request.url.toString())

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(v: WebView, target: String): Boolean =
                routeUrl(target)

            override fun onPageFinished(v: WebView, pageUrl: String) {
                saveUrl("history", pageUrl)
            }
        }
        return view
    }

    private fun routeUrl(url: String): Boolean {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase() ?: return true
        if (scheme != "http" && scheme != "https") {
            return try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
                true
            } catch (_: Exception) {
                Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show()
                true
            }
        }

        val pathAndQuery = (uri.path.orEmpty() + "?" + uri.query.orEmpty()).lowercase()
        val isVideo = listOf(".mp4", ".m3u8", ".mpd", ".webm", ".mkv")
            .any { pathAndQuery.contains(it) }
        if (isVideo) {
            return try {
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, when {
                        pathAndQuery.contains(".m3u8") -> "application/vnd.apple.mpegurl"
                        pathAndQuery.contains(".mpd") -> "application/dash+xml"
                        else -> "video/*"
                    })
                })
                true
            } catch (_: Exception) {
                Toast.makeText(this, "Не найден совместимый видеоплеер", Toast.LENGTH_LONG).show()
                true
            }
        }

        // Обычные HTTP(S)-ссылки оставляем текущему WebView.
        // Это важно для промежуточных страниц, авторизации и выдачи ссылок LostFilm.
        return false
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webContainer.isInitialized && popupStack.isNotEmpty()) {
            val popup = popupStack.last()
            if (popup.canGoBack()) {
                popup.goBack()
            } else {
                popupStack.removeAt(popupStack.lastIndex)
                webContainer.removeView(popup)
                popup.destroy()
                if (popupStack.isEmpty()) web?.bringToFront()
                else popupStack.last().bringToFront()
            }
            return
        }
        val current = web
        if (current != null && current.canGoBack()) current.goBack()
        else { web = null; showHome() }
    }
}
