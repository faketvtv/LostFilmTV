# LostFilm TV v0.9

Android TV / Google TV client shell with LostFilm website browsing, visible popup-window handling, and improved external link routing.

## External playback
- Direct compatible video URLs (`.mp4`, `.m3u8`, `.mpd`, `.webm`, `.mkv`) are offered to an installed external player.
- Torrent links (`magnet:` and `.torrent`) are offered to an installed torrent client.
- Other website pages remain inside the app; the existing Tracktor external-browser routing is preserved.
- Torrent files are not video streams and are not converted into streams.

## Build with GitHub Actions
Upload the **contents** of this project to the repository root, including `.github/workflows/android.yml`, then open Actions and run `Build LostFilm TV APK` from the `v0.9-external-playback` branch.

## Install
Download the `LostFilmTV-APK` artifact from a successful Actions run, extract `app-debug.apk`, and install it on Android TV / Google TV.
