package tv.lostfilm.app

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val homeUrl = "https://lostfilm.tv/"
    private lateinit var root: LinearLayout
    private var web: WebView? = null
    private var popupWeb: WebView? = null
    private var popupDialog: Dialog? = null
    private val prefs by lazy { getSharedPreferences("lostfilm_tv", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(34, 26, 34, 26)
        setBackgroundColor(Color.rgb(16, 20, 29))
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply {
            text = label
            textSize = 18f
            isFocusable = true
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 62).apply {
                bottomMargin = 12
            }
        })
    }

    private fun showHome() {
        root = base()
        root.addView(TextView(this).apply {
            text = "LOSTFILM TV"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 20)
        })
        addButton(root, "Каталог сериалов", { openSite(homeUrl) })
        addButton(root, "Поиск на LostFilm", { showSearch() })
        addButton(root, "Избранное", { openSaved("favorites") })
        addButton(root, "История просмотров", { openSaved("history") })
        addButton(root, "Открыть сайт LostFilm", { openSite(homeUrl) })
        root.addView(TextView(this).apply {
            text = "Каталог и карточки сериалов загружаются с сайта LostFilm. Прямые совместимые видеоссылки можно открыть во внешнем плеере."
            textSize = 14f
            setTextColor(Color.LTGRAY)
        })
        setContentView(root)
        root.getChildAt(1).requestFocus()
    }

    private fun showSearch() {
        root = base()
        root.addView(TextView(this).apply {
            text = "Поиск сериалов"
            textSize = 24f
            setTextColor(Color.WHITE)
        })
        val field = EditText(this).apply {
            hint = "Название сериала"
            textSize = 18f
            setSingleLine(true)
        }
        root.addView(field)
        addButton(root, "Искать на сайте", {
            val q = Uri.encode(field.text.toString().trim())
            if (q.isNotEmpty()) openSite("$homeUrl?search=$q")
            else Toast.makeText(this, "Введите название", Toast.LENGTH_SHORT).show()
        })
        addButton(root, "Назад", ::showHome)
        setContentView(root)
        field.requestFocus()
    }

    private fun openSaved(kind: String) {
        val values = prefs.getStringSet(kind, emptySet()).orEmpty().toList()
        root = base()
        root.addView(TextView(this).apply {
            text = if (kind == "favorites") "Избранное" else "История"
            textSize = 24f
            setTextColor(Color.WHITE)
        })
        if (values.isEmpty()) root.addView(TextView(this).apply {
            text = "Пока пусто. Добавляйте страницы сайта в избранное через меню приложения."
            setTextColor(Color.LTGRAY)
        })
        values.forEach { url -> addButton(root, url, { openSite(url) }) }
        addButton(root, "Назад", ::showHome)
        setContentView(root)
    }

    private fun saveUrl(kind: String, url: String) {
        val set = prefs.getStringSet(kind, emptySet()).orEmpty().toMutableSet()
        set.remove(url)
        set.add(url)
        while (set.size > 50) set.remove(set.first())
        prefs.edit().putStringSet(kind, set).apply()
    }

    private fun openSite(url: String) {
        val view = WebView(this)
        web = view
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.javaScriptCanOpenWindowsAutomatically = true
        view.settings.setSupportMultipleWindows(true)
        view.settings.mediaPlaybackRequiresUserGesture = true
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, true)
        view.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                val popup = WebView(this@MainActivity).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.javaScriptCanOpenWindowsAutomatically = true
                    settings.setSupportMultipleWindows(true)
                    settings.mediaPlaybackRequiresUserGesture = true
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                }
                val dialog = Dialog(this@MainActivity).apply {
                    setContentView(popup)
                    window?.setLayout(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setOnDismissListener {
                        popup.stopLoading()
                        popup.destroy()
                        if (popupWeb === popup) popupWeb = null
                        if (popupDialog === this) popupDialog = null
                    }
                }
                popup.webChromeClient = object : WebChromeClient() {
                    override fun onCloseWindow(window: WebView?) {
                        popupDialog?.dismiss()
                    }
                }
                popup.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean =
                        routeUrl(request.url.toString())

                    @Deprecated("Deprecated in Java")
                    override fun shouldOverrideUrlLoading(v: WebView, target: String): Boolean =
                        routeUrl(target)
                }
                popupWeb = popup
                popupDialog = dialog
                dialog.show()
                dialog.window?.setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                transport.webView = popup
                resultMsg.sendToTarget()
                return true
            }
        }
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean =
                routeUrl(request.url.toString())

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(v: WebView, target: String): Boolean =
                routeUrl(target)

            override fun onPageFinished(v: WebView, pageUrl: String) {
                saveUrl("history", pageUrl)
            }
        }
        setContentView(view)
        view.loadUrl(url)
    }

    private fun videoExtension(uri: Uri): String? {
        val candidates = listOf(
            uri.lastPathSegment.orEmpty(),
            uri.getQueryParameter("filename").orEmpty(),
            uri.getQueryParameter("file").orEmpty(),
            uri.getQueryParameter("url").orEmpty()
        ).map { it.substringBefore('?').lowercase() }

        val extensions = listOf(".mp4", ".m3u8", ".mpd", ".webm", ".mkv")
        for (candidate in candidates) {
            extensions.firstOrNull { candidate.endsWith(it) }?.let { return it }
        }

        val declaredFormat = sequenceOf("format", "type", "ext")
            .mapNotNull { uri.getQueryParameter(it)?.lowercase()?.removePrefix(".") }
            .firstOrNull()
        return declaredFormat?.let { ".$it" }?.takeIf { ext -> extensions.contains(ext) }
    }

    private fun isTorrentUri(uri: Uri): Boolean {
        if (uri.scheme.equals("magnet", ignoreCase = true)) return true
        if (uri.path.orEmpty().lowercase().endsWith(".torrent")) return true
        return sequenceOf("type", "format", "download")
            .mapNotNull { uri.getQueryParameter(it)?.lowercase() }
            .any { it == "torrent" || it == "application/x-bittorrent" }
    }

    private fun videoMime(extension: String): String = when (extension) {
        ".mp4" -> "video/mp4"
        ".webm" -> "video/webm"
        ".mkv" -> "video/x-matroska"
        ".m3u8" -> "application/vnd.apple.mpegurl"
        ".mpd" -> "application/dash+xml"
        else -> "video/*"
    }

    private fun openExternal(uri: Uri, mimeType: String?, chooserTitle: String, errorMessage: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                if (mimeType != null) setDataAndType(uri, mimeType)
                addCategory(Intent.CATEGORY_DEFAULT)
            }
            startActivity(Intent.createChooser(intent, chooserTitle))
        } catch (_: Exception) {
            Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()
        }
    }

    private fun routeUrl(url: String): Boolean {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase() ?: return true

        if (isTorrentUri(uri)) {
            openExternal(
                uri,
                if (scheme == "http" || scheme == "https") "application/x-bittorrent" else null,
                "Открыть торрент",
                "Не найдено приложение для открытия торрентов"
            )
            return true
        }

        if (scheme != "http" && scheme != "https") {
            return try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
                true
            } catch (_: Exception) {
                Toast.makeText(this, "Нет приложения для открытия этой ссылки", Toast.LENGTH_LONG).show()
                true
            }
        }

        val extension = videoExtension(uri)
        if (extension != null) {
            openExternal(
                uri,
                videoMime(extension),
                "Открыть видео в плеере",
                "Установите совместимый видеоплеер, например VLC или MX Player"
            )
            return true
        }

        if (uri.host?.contains("tracktor.site", true) == true) {
            return try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
                true
            } catch (_: Exception) {
                Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_LONG).show()
                true
            }
        }
        return false
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val popup = popupWeb
        if (popupDialog?.isShowing == true) {
            if (popup != null && popup.canGoBack()) popup.goBack()
            else popupDialog?.dismiss()
            return
        }
        val current = web
        if (current != null && current.canGoBack()) current.goBack()
        else {
            web = null
            showHome()
        }
    }
}
