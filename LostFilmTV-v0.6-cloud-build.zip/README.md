# LostFilm TV v0.6

Android TV / Google TV native launcher with a WebView for the LostFilm website.

## Build with GitHub Actions
1. Upload the contents of this project to the repository root, or upload this ZIP alone and use the workflow below.
2. Keep only one project ZIP in the repository root to avoid extracting an older version.
3. Commit `.github/workflows/android.yml` and run **Build LostFilm TV APK** from the Actions tab.
4. Download the `LostFilmTV-APK` artifact from the completed workflow.

The app sends `tracktor.site` pages to an external browser because those are redirect/download pages, not necessarily direct video streams. A compatible direct video URL is sent to an installed external player. This does not bypass site login, DRM, or access restrictions. Actual playback depends on the destination page, installed browser/player, and the site's current behavior.
