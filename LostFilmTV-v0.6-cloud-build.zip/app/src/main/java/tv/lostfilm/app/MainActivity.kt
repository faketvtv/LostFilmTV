package tv.lostfilm.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val site = "https://lostfilm.tv/"
    private lateinit var root: LinearLayout
    private lateinit var webContainer: FrameLayout
    private var webView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(36, 28, 36, 28)
        setBackgroundColor(Color.rgb(16, 20, 28))
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 19f
        isFocusable = true
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 64).apply {
            bottomMargin = 14
        }
    }

    private fun showHome() {
        root = base()
        root.addView(TextView(this).apply {
            text = "LOSTFILM TV"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 26)
        })
        root.addView(button("Открыть LostFilm", ::openSite))
        root.addView(button("Избранное", { openSite() }))
        root.addView(button("История", { openSite() }))
        root.addView(TextView(this).apply {
            text = "Авторизуйтесь на сайте. Ссылки, открывающиеся в новых окнах, переводятся в текущее окно. Страницы tracktor.site открываются во внешнем браузере."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(4, 18, 4, 0)
        })
        setContentView(root)
        root.getChildAt(1).requestFocus()
    }

    private fun openSite() {
        webContainer = FrameLayout(this)
        val web = WebView(this)
        webView = web
        configureWebView(web)
        webContainer.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(webContainer)
        web.loadUrl(site)
    }

    @Suppress("SetJavaScriptEnabled")
    private fun configureWebView(web: WebView) {
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        // New-window links are handled in the same WebView instead of being silently dropped.
        web.settings.setSupportMultipleWindows(false)
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                handleUrl(request.url)

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean =
                handleUrl(Uri.parse(url))

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                // Normalize target=_blank and window.open links for Android WebView.
                view.evaluateJavascript(
                    "(function(){" +
                        "document.querySelectorAll('a[target=_blank]').forEach(function(a){a.target='_self';});" +
                        "var oldOpen=window.open; window.open=function(u){if(u){window.location.href=u;} return window;};" +
                    "})();", null
                )
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?, isDialog: Boolean, isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                // Multiple windows are disabled intentionally. The page script above
                // redirects window.open to the current WebView. Do not create a blank popup.
                return false
            }
        }
    }

    private fun handleUrl(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") return true

        val host = uri.host?.lowercase().orEmpty()
        if (host == "tracktor.site" || host.endsWith(".tracktor.site")) {
            openExternal(uri)
            return true
        }

        val path = uri.path?.lowercase().orEmpty()
        val isVideo = listOf(".mp4", ".m3u8", ".mpd", ".mkv", ".webm").any { path.endsWith(it) }
        if (isVideo) {
            openExternal(uri)
            return true
        }
        return false
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Не найдено приложение для открытия ссылки", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val web = webView
        if (web != null && web.canGoBack()) {
            web.goBack()
        } else if (web != null) {
            web.stopLoading()
            web.destroy()
            webView = null
            setContentView(root)
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        webView?.destroy()
        webView = null
        super.onDestroy()
    }
}
